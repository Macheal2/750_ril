#ifndef __RESETEP_H_
#define __RESETEP_H_
#include "getdevinfo.h"
int reset_ep(int infNum, int ep);
#endif
